<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://about.me/bharatkambariya
 * @since      2.1.0
 *
 * @package    Donations_Block
 * @subpackage Donations_Block/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
